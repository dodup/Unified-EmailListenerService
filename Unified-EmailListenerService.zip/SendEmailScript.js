"use strict";
var ConnectRuntime = require("./Bindings/njs/opn.js"); /*import Comfort api*/
const nodemailer = require("nodemailer"); /* Node Js Module*/
const net = require("net");
const readline = require("readline");
// used to collect the tag values needed within the email
var tagsReadCompleted = []; // Array to store read tags received from runtime
var tagsToRead = []; // Array to store to be read tags
tagsToRead.push("_EMAIL_.to");
tagsToRead.push("_EMAIL_.from");
tagsToRead.push("_EMAIL_.subject");
tagsToRead.push("_EMAIL_.body");
tagsToRead.push("_EMAIL_.trigger");
tagsToRead.push("_SMTP_.host");
tagsToRead.push("_SMTP_.port");
tagsToRead.push("_SMTP_.secure");
tagsToRead.push("_SMTP_.requireTLS");
tagsToRead.push("_SMTP_.auth_user");
tagsToRead.push("_SMTP_.auth_pass");
let trigger = false;
let params = {};
let smtpOptions = {
  auth: {},
};

/* Connect To runtime*/
ConnectRuntime.Connect((runtimeClass) => {
  let runtime = runtimeClass.Runtime;
  runtime.on("NotifySubscribeTag", (tagsList, cookie) => {
    for (let tagobject of tagsList) {
      if (tagobject.Name == "_EMAIL_.trigger") {
        if (parseInt(tagobject.Value) === 1) {
          trigger = true;
        } else {
          trigger = false;
        }
        runtime.ReadTag(tagsToRead, "ReadTagCookie");
      }
    }
  });
  runtime.on("NotifyReadTag", (tagsList, cookie) => {
    SendEmailHandler(tagsList);
  });
  /* Subscribe Tag*/
  runtime.SubscribeTag(["_EMAIL_.trigger"], "SubscribeTagCookie");
});

/*Send Email function*/
function SendEmailHandler(tagsList) {
  // if (trigger) {
  /* Since this sample is written with 'SetOption EnableExpertMode' via comfort layer, then response will be always in JSON mode */
  if (tagsList) {
    for (let tagData of tagsList) {
      //Preparing email parameters
      switch (tagData.Name) {
        case "_EMAIL_.to":
          params.to = tagData.Value;
          break;
        case "_EMAIL_.from":
          params.from = tagData.Value;
          break;
        case "_EMAIL_.subject":
          params.subject = tagData.Value;
          break;
        case "_EMAIL_.body":
          params.body = tagData.Value;
          break;
        case "_EMAIL_.trigger":
          tagData.Value == "TRUE" ? (trigger = true) : (trigger = false);
          break;
        case "_SMTP_.host":
          smtpOptions.host = tagData.Value;
          break;
        case "_SMTP_.port":
          smtpOptions.port = parseInt(tagData.Value);
          break;
        case "_SMTP_.secure":
          tagData.Value == "TRUE"
            ? (smtpOptions.secure = true)
            : (smtpOptions.secure = false);
          break;
        case "_SMTP_.requireTLS":
          tagData.Value == "TRUE"
            ? (smtpOptions.requireTLS = true)
            : (smtpOptions.requireTLS = false);
          break;
        case "_SMTP_.auth_user":
          smtpOptions.auth.user = tagData.Value;
          break;
        case "_SMTP_.auth_pass":
          smtpOptions.auth.pass = tagData.Value;
          break;
        default:
        //console.log(`No suitable tags found.`);
      }

      tagsReadCompleted.push(tagData.Name);
    }
    /*Check whether all tags read or not, if read send e-mail*/
    if (compare(tagsReadCompleted, tagsToRead)) {
      tagsReadCompleted = [];
      if (trigger) {
        sendEmail(params)
          .then((error) => {
            //console.log(`Send Email succeeded`);
            writeValue("_EMAIL_.trigger", "0");
          })
          .catch((error) => {
            //console.log(`Send Email failed, error ${error}`);
          });
      }
    }
  }
}
// async function, returns Promise
function sendEmail(params) {
  return new Promise(function (resolve, reject) {
    if (!smtpOptions.proxy) {
      // take proxy from env when it is not set in options
      smtpOptions.proxy = process.env.http_proxy;
    }
    let transporter = nodemailer.createTransport(smtpOptions);
    transporter.sendMail(
      {
        from: params.from,
        to: params.to,
        subject: params.subject,
        text: params.body,
      },
      function (err) {
        if (err) {
          //console.log(`send: err = ${err}`);
          reject(err);
        } else {
          resolve();
        }
      }
    );
  });
}

/*Array Compare function*/
function compare(a, b) {
  a.sort();
  b.sort();
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (a.length != b.length) return false;

  for (var i = 0; i < a.length; ++i) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function writeValue(tag, value) {
  //open named pipe
  let client = net.connect("\\\\.\\pipe\\HmiRuntime", () => {
    const rl = readline.createInterface({
      input: client,
      crlfDelay: Infinity,
    });

    rl.on("line", function (line) {
      var tokens = line.split(/[\s,]+/);
      var cmd = tokens.shift();
      if ("NotifyWriteTagValue" == cmd) {
        var tagName = tokens.shift();
        //console.log("\ncommand:" + cmd + "\ntagName:" + tagName);
      }
      if ("ErrorWriteTagValue" == cmd) {
        //console.log(line);
      }

      client.end();
    });
    client.on("end", function () {
      //console.log("on end");
    });

    client.write(`WriteTagValue ${tag} ${value}\n`);
  });
}
